#include "misc.h"
#include "platform.h"
#include "zcharlie.h"

static const void set_dir(int pin_id, int dir)
{
  if(pin_id < 0)
    return;
  const uint32_t ports[] = {GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB};
  const uint16_t pins[] = {GPIO_PIN_15, GPIO_PIN_14, GPIO_PIN_13, GPIO_PIN_12,
    GPIO_PIN_11, GPIO_PIN_10, GPIO_PIN_1};
  const auto& port = ports[pin_id];
  const auto& pin = pins[pin_id];
  if(dir == ZCHARLIE::IN)
    gpio_init(port, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, pin);
  else {
    gpio_init(port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, pin);
    if(dir == ZCHARLIE::L)
      gpio_bit_reset(port, pin);
    else if(dir == ZCHARLIE::H)
      gpio_bit_set(port, pin);
  }
}

static const void set_dir2(int pin_id, int dir)
{
  if(pin_id < 0)
    return;
  const uint32_t ports[] = {GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB};
  const uint16_t pins[] = {GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7, GPIO_PIN_8, GPIO_PIN_9};
//  const uint32_t ports[] = {GPIOA, GPIOA, GPIOA, GPIOA, GPIOC, GPIOC, GPIOC};
//  const uint16_t pins[] = {GPIO_PIN_8, GPIO_PIN_11, GPIO_PIN_12, GPIO_PIN_15, GPIO_PIN_13, GPIO_PIN_14, GPIO_PIN_15};

  const auto& port = ports[pin_id];
  const auto& pin = pins[pin_id];
  if(dir == ZCHARLIE::IN)
    gpio_init(port, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, pin);
  else {
    gpio_init(port, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, pin);
    if(dir == ZCHARLIE::L)
      gpio_bit_reset(port, pin);
    else if(dir == ZCHARLIE::H)
      gpio_bit_set(port, pin);
  }
}

const ZCHARLIE::leds_t leds[24] = {
//
  {1, 6}, {3, 6}, {5, 6}, {6, 4}, {4, 6}, {6, 5}, {1, 5}, {-1, -1},    //
  {5, 4}, {3, 5}, {4, 5}, {3, 4}, {6, 3}, {4, 3}, {5, 3}, {3, 1},    //
  {2, 3}, {2, 4}, {5, 2}, {2, 6}, {2, 5}, {3, 2}, {4, 2}, {2, 1}    //
};

const ZCHARLIE::leds_t leds2[32] = {
//
  {3, 4}, {3, 5}, {3, 6}, {3, 7}, {4, 5}, {4, 6}, {4, 7}, {-1, -1},    //
  {4, 3}, {5, 3}, {6, 3}, {7, 3}, {5, 4}, {6, 4}, {7, 4}, {6, 2},    //
  {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7}, {2, 3}, {2, 6},    //
  {2, 1}, {3, 1}, {4, 1}, {5, 1}, {6, 1}, {7, 1}, {3, 2}, {2, 3},    //
  };

ZCHARLIE charlie(set_dir, leds, 24, 6);
ZCHARLIE charlie2(set_dir2, leds2, 32, 7);

void DISP_Config(void)
{
  rcu_periph_clock_enable (RCU_GPIOA);
  rcu_periph_clock_enable (RCU_GPIOB);
  rcu_periph_clock_enable (RCU_GPIOC);
  gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);    // enable PB3~PB5
}

void DISP_Poll(void)
{
//  charlie.poll_led();
//  charlie2.poll_led();
  charlie.poll_pin();
  charlie2.poll_pin();
}

