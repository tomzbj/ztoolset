#ifndef _TASKS_H
#define _TASKS_H

void TASKS_Config(void);

#endif
