#include "misc.h"
#include "platform.h"
#include "zcharlie.h"

#define ok() printf("ok\n");

ZCli cli(20);

static void cli_rd_sbrk_sp(const char* tokens[])
{
  register uint8_t* sp asm("sp");
  auto a1 = sp;
  auto a2 = malloc(1);
  printf("%p %p %d\n", a1, a2, (int)a1 - (int)a2);
  free(a2);
}

/* @formatter:off */
const auto test_f = [](const char**) {puts("TEST OK");};
const auto reboot_f = [](const char**) {puts("REBOOT."); NVIC_SystemReset();};
const auto rd_freq_f = [](const char**) {printf("%lu\n", rcu_clock_freq_get(CK_SYS));};
/* @formatter:on */

void CLI_Config(void)
{
  extern class ZCHARLIE charlie;
  cli.bind("test", test_f);
  cli.bind("reboot", reboot_f);
  cli.bind("sbrk_sp", "rd", cli_rd_sbrk_sp);
  cli.bind("freq", "rd", rd_freq_f);

  print_log();
}
