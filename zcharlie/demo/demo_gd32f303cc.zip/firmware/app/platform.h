#ifndef _PLATFORM_H
#define _PLATFORM_H

#include "cocoos.h"

// thirdparty
#include "zuart3.h"
#include "zpin.h"
#include "zcli.h"

// bsp
#include "usart_gdf3.h"

// app
#include "app.h"
#include "cli.h"
#include "disp.h"

// drv

extern class ZUart3 u0;
extern class ZCli cli;
extern class ZCHARLIE charlie;

#endif
