#ifndef _DISP_H
#define _DISP_H

void DISP_Config(void);
void DISP_Poll(void);

#endif
