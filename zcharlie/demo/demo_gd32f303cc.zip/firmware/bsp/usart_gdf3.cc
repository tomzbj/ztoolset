#include "platform.h"
#include "misc.h"

//#define RXBUF_SIZE 128
//static uint8_t rxbuf[RXBUF_SIZE];

/*
 extern "C" void DMA0_Channel4_IRQHandler(void)
 {
 if(dma_interrupt_flag_get(DMA0, DMA_CH4, DMA_INT_FLAG_HTF)) {
 dma_interrupt_flag_clear(DMA0, DMA_CH4, DMA_INT_FLAG_G);
 u0.push(rxbuf, RXBUF_SIZE / 2);
 }
 if(dma_interrupt_flag_get(DMA0, DMA_CH4, DMA_INT_FLAG_FTF)) {
 dma_interrupt_flag_clear(DMA0, DMA_CH4, DMA_INT_FLAG_G);
 u0.push(&rxbuf[RXBUF_SIZE / 2], RXBUF_SIZE / 2);
 }
 }
 */

static void usart_clear_idle(void)
{
  volatile uint32_t tmp = 0;
  tmp = USART_STAT0(USART0);
  tmp = USART_DATA(USART0);
  tmp = tmp;
}

extern "C" void USART0_IRQHandler(void)
{
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_RBNE) != RESET) {
//    _dbg();
//    u0.rxne_irqhandler();
    uint8_t c = USART_DATA(USART0);
    u0.push(&c, 1);    //rxbuf, size);
    usart_interrupt_flag_clear(USART0, USART_INT_FLAG_RBNE);
  }
  /*
   if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_IDLE) != RESET) {
   usart_clear_idle();
   dma_channel_disable(DMA0, DMA_CH4);
   int size = RXBUF_SIZE - dma_transfer_number_get(DMA0, DMA_CH4);
   dma_transfer_number_config(DMA0, DMA_CH4, RXBUF_SIZE);
   if(size < RXBUF_SIZE / 2) {
   u0.push(rxbuf, size);
   }
   else {
   u0.push(&rxbuf[RXBUF_SIZE / 2], size - RXBUF_SIZE / 2);
   }
   dma_channel_enable(DMA0, DMA_CH4);
   }
   */
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_ERR_NERR) != RESET) {
    usart_clear_idle();
  }
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_ERR_ORERR) != RESET) {
    usart_clear_idle();
  }
  if(usart_interrupt_flag_get(USART0, USART_INT_FLAG_ERR_FERR) != RESET) {
    usart_clear_idle();
  }
}

/*
 extern "C" void USART0_Write_DMA(uint8_t* data, int count)
 {
 dma_channel_disable(DMA0, DMA_CH3);
 DMA_CHCNT(DMA0, DMA_CH3) = count;
 DMA_CHMADDR(DMA0, DMA_CH3) = (uint32_t)(data);
 dma_channel_enable(DMA0, DMA_CH3);
 usart_dma_transmit_config(USART0, USART_DENT_ENABLE);
 while(!dma_flag_get(DMA0, DMA_CH3, DMA_INT_FLAG_FTF));
 dma_flag_clear(DMA0, DMA_CH3, DMA_FLAG_FTF);
 }
 */

void USART0_Write(uint8_t* data, int count)
{
  for(int i = 0; i < count; i++)
    USART0_WriteByte(data[i]);
}

void USART0_WriteByte(uint8_t c)
{
  usart_data_transmit(USART0, c);
  while(RESET == usart_flag_get(USART0, USART_FLAG_TC));
}

void USART_Config(void)
{
  rcu_periph_clock_enable (RCU_GPIOA);
  // PA9&10 as USART0
  gpio_init(GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);
  gpio_init(GPIOA, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, GPIO_PIN_10);

  rcu_periph_clock_enable (RCU_USART0); /* enable USART clock */
  rcu_periph_clock_enable (RCU_AF);
  __disable_irq();
  usart_disable (USART0);
  usart_deinit(USART0); /* USART configure */
  usart_word_length_set(USART0, USART_WL_8BIT);
  usart_stop_bit_set(USART0, USART_STB_1BIT);
  usart_parity_config(USART0, USART_PM_NONE);
  usart_baudrate_set(USART0, 500000UL);
  usart_receive_config(USART0, USART_RECEIVE_ENABLE);
  usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);
  usart_enable(USART0);
  usart_interrupt_enable(USART0, USART_INT_ERR);
//  usart_interrupt_enable(USART0, USART_INT_IDLE);
  usart_interrupt_enable(USART0, USART_INT_RBNE);
  nvic_irq_enable(USART0_IRQn, 1, 0);
  __enable_irq();

  /*
   dma_parameter_struct dis;
   rcu_periph_clock_enable (RCU_DMA0);
   dma_deinit(DMA0, DMA_CH4);
   dis.periph_addr = (uint32_t)&USART_DATA(USART0);
   dis.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
   dis.periph_inc = DMA_PERIPH_INCREASE_DISABLE;
   dis.memory_addr = (uint32_t)(rxbuf);
   dis.memory_width = DMA_MEMORY_WIDTH_8BIT;
   dis.memory_inc = DMA_MEMORY_INCREASE_ENABLE;
   dis.direction = DMA_PERIPHERAL_TO_MEMORY;
   dis.number = sizeof(rxbuf);
   dis.priority = DMA_PRIORITY_ULTRA_HIGH;
   dma_init(DMA0, DMA_CH4, &dis);
   dis.periph_addr = (uint32_t)&USART_DATA(USART0);
   dis.direction = DMA_MEMORY_TO_PERIPHERAL;
   dma_init(DMA0, DMA_CH3, &dis);

   dma_circulation_enable(DMA0, DMA_CH4);
   dma_memory_to_memory_disable(DMA0, DMA_CH4);
   dma_channel_enable(DMA0, DMA_CH4);
   usart_dma_receive_config(USART0, USART_DENR_ENABLE);
   dma_interrupt_enable(DMA0, DMA_CH4, DMA_INT_FTF);
   dma_interrupt_enable(DMA0, DMA_CH4, DMA_INT_HTF);

   dma_circulation_disable(DMA0, DMA_CH3);
   dma_memory_to_memory_disable(DMA0, DMA_CH3);
   nvic_irq_enable(DMA0_Channel4_IRQn, 0, 0);
   */

//  while(1) { USART0_WriteByte('K'); _delay_ms(100); }
  printf("\n\n");
  print_log();
}
