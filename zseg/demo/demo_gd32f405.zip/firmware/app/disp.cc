#include "misc.h"
#include "platform.h"
#include "zseg.h"

static void set_seg(int seg, int state)
{
  const zpin_t segs[] = {PB12, PA3, PB1, PB13, PB14, PB10, PA6, PB11};
  ZPin::write(segs[seg], state);
}
static void set_dig(int dig, int state)
{
  const zpin_t digs[] = {PA4, PA5, PA7, PB15};
  ZPin::write(digs[dig], state);
}

ZSEG::cbs_t cbs = {.set_seg_f = set_seg, .set_dig_f = set_dig};

ZSEG seg(cbs, 8, 4);

void DISP_Config(void)
{
  rcu_periph_clock_enable (RCU_GPIOA);
  rcu_periph_clock_enable (RCU_GPIOB);

  auto pins = GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
  gpio_mode_set(GPIOA, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, pins);
  gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pins);
  pins = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15 | GPIO_PIN_1 | GPIO_PIN_10
    | GPIO_PIN_11 | GPIO_PIN_12;
  gpio_mode_set(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, pins);
  gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pins);

  print_log();
//  seg.set_raw((uint8_t*)"\xf0\x0f\x55\xaa");
  seg.write(1234);    //raw((uint8_t*)"\xf0\x0f\x55\xaa");
}

void DISP_Poll(void)
{
  seg.poll();

  if(0) {
    static int count = 0;
    ++count %= 500;
    if(!count) {
//      for(int i = 0; i < 4; i++) { printf("%02x ", seg._vram[i]); }
//      printf("\n");
    }
  }
}

