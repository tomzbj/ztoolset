#ifndef _CLI_H
#define _CLI_H

void CLI_Config(void);

#endif
